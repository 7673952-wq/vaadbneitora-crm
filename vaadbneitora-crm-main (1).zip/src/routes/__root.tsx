import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { supabase } from "@/integrations/supabase/client";
import { applyStatusSettings } from "@/lib/status";
import { listStatusSettings } from "@/lib/admin.functions";
import { getAuthHeaders } from "@/lib/auth-headers";
import { useServerFn } from "@tanstack/react-start";
import { Toaster } from "sonner";

function NotFoundComponent() {
  return (
    <div dir="rtl" className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold">הדף לא נמצא</h2>
        <p className="mt-2 text-sm text-muted-foreground">הדף שחיפשת לא קיים או הוסר.</p>
        <div className="mt-6">
          <Link to="/" className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90">
            חזרה לדף הבית
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => { reportLovableError(error, { boundary: "tanstack_root_error_component" }); }, [error]);
  return (
    <div dir="rtl" className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold">משהו השתבש</h1>
        <p className="mt-2 text-sm text-muted-foreground">נסה שוב או חזור לדף הבית.</p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button onClick={() => { router.invalidate(); reset(); }} className="inline-flex rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90">
            נסה שוב
          </button>
          <a href="/" className="inline-flex rounded-md border border-input bg-background px-4 py-2 text-sm font-medium hover:bg-accent">
            דף הבית
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "CRM ניהול מערכות" },
      { name: "description", content: "מערכת ניהול לקוחות ומערכות עם מעקב, היסטוריית העברות והרשאות." },
      { property: "og:title", content: "CRM ניהול מערכות" },
      { property: "og:description", content: "מערכת ניהול לקוחות ומערכות עם מעקב, היסטוריית העברות והרשאות." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:title", content: "CRM ניהול מערכות" },
      { name: "twitter:description", content: "מערכת ניהול לקוחות ומערכות עם מעקב, היסטוריית העברות והרשאות." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/3310efe0-49bc-42e5-b183-3f0973a16b9b/id-preview-3455b488--bee711c7-69fe-4131-9859-c15e001815c1.lovable.app-1781804335816.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/3310efe0-49bc-42e5-b183-3f0973a16b9b/id-preview-3455b488--bee711c7-69fe-4131-9859-c15e001815c1.lovable.app-1781804335816.png" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Heebo:wght@300;400;500;600;700;800&display=swap" },
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="he" dir="rtl">
      <head><HeadContent /></head>
      <body>{children}<Scripts /></body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  const router = useRouter();

  useEffect(() => {
    // Force re-login on every browser/tab close: sessionStorage clears on close,
    // localStorage (where Supabase persists) does not. If we have no marker but
    // a session exists, it's a stale session from a previous tab — sign out.
    //
    // Caveat: sessionStorage is per-tab and is NOT copied into a brand-new tab
    // opened with rel="noopener"/"noreferrer" (e.g. our "פתח בלשונית נפרדת"
    // button, or a plain ctrl/cmd-click). Without the guard below, opening
    // such a tab looked exactly like "stale session from a previous browser
    // session" and force-signed the user out, bouncing them to /auth. We tell
    // the two cases apart by tracking how many tabs are currently open (in
    // localStorage, shared across tabs): if another tab was already open when
    // this one loaded, it's a legitimate new tab of the same session — adopt
    // the marker instead of signing out. Only sign out when this is truly the
    // first tab (i.e. the whole browser was closed and reopened).
    const SESSION_MARKER = "crm_active_session";
    const TAB_COUNT_KEY = "crm_open_tab_count";

    function getTabCount(): number {
      const n = parseInt(localStorage.getItem(TAB_COUNT_KEY) || "0", 10);
      return Number.isFinite(n) && n > 0 ? n : 0;
    }
    function setTabCount(n: number) {
      localStorage.setItem(TAB_COUNT_KEY, String(Math.max(0, n)));
    }

    const otherTabsWereOpen = getTabCount() > 0;
    setTabCount(getTabCount() + 1);
    let registered = true;
    function unregisterTab() {
      if (!registered) return;
      registered = false;
      setTabCount(getTabCount() - 1);
    }
    window.addEventListener("pagehide", unregisterTab);
    window.addEventListener("beforeunload", unregisterTab);

    (async () => {
      const { data } = await supabase.auth.getSession();
      if (data.session && !sessionStorage.getItem(SESSION_MARKER)) {
        if (otherTabsWereOpen) {
          sessionStorage.setItem(SESSION_MARKER, "1");
        } else {
          await supabase.auth.signOut();
        }
      }
    })();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === "SIGNED_IN") sessionStorage.setItem(SESSION_MARKER, "1");
      if (event === "SIGNED_OUT") sessionStorage.removeItem(SESSION_MARKER);
      if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED") return;
      router.invalidate();
      if (event !== "SIGNED_OUT") queryClient.invalidateQueries();
    });
    return () => {
      subscription.unsubscribe();
      window.removeEventListener("pagehide", unregisterTab);
      window.removeEventListener("beforeunload", unregisterTab);
      unregisterTab();
    };
  }, [router, queryClient]);

  return (
    <QueryClientProvider client={queryClient}>
      <StatusSettingsHydrator />
      <Outlet />
      <Toaster position="top-center" richColors dir="rtl" />
    </QueryClientProvider>
  );
}

function StatusSettingsHydrator() {
  const fn = useServerFn(listStatusSettings);
  const [hasSession, setHasSession] = useState(false);
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setHasSession(!!data.session));
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, session) => {
      setHasSession(!!session);
    });
    return () => subscription.unsubscribe();
  }, []);
  const { data } = useQuery({
    queryKey: ["status_settings"],
    queryFn: async () => fn({ headers: await getAuthHeaders() }),
    enabled: hasSession,
    staleTime: 60_000,
    retry: false,
    throwOnError: false,
  });
  useEffect(() => { if (data) applyStatusSettings(data as any); }, [data]);
  return null;
}
